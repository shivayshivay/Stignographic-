package com.forensics.stego.core

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Password-based encryption for a hidden message's payload.
 * Layout: 16-byte salt + 12-byte IV + AES-256-GCM ciphertext (tag included).
 * PBKDF2-HMAC-SHA256 with 150,000 iterations derives the key, matching the
 * desktop/web version of this tool so files are interchangeable.
 */
object CryptoUtil {
    private const val ITERATIONS = 150_000
    private const val KEY_LEN_BITS = 256

    fun seal(plaintext: ByteArray, password: String): ByteArray {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val key = deriveKey(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val ct = cipher.doFinal(plaintext)
        return salt + iv + ct
    }

    /** Throws (typically javax.crypto.AEADBadTagException) when the password is wrong. */
    fun unseal(blob: ByteArray, password: String): ByteArray {
        if (blob.size < 29) throw IllegalArgumentException("Corrupt data")
        val salt = blob.copyOfRange(0, 16)
        val iv = blob.copyOfRange(16, 28)
        val ct = blob.copyOfRange(28, blob.size)
        val key = deriveKey(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return cipher.doFinal(ct)
    }

    private fun deriveKey(password: String, salt: ByteArray): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LEN_BITS)
        val bytes = factory.generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }
}
