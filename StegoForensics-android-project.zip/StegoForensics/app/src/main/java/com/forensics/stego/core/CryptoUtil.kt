package com.forensics.stego.core

import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Password-based encryption for a hidden message's payload.
 * Layout: 16-byte salt + 12-byte IV + AES-256-GCM ciphertext (tag included).
 * PBKDF2-HMAC-SHA256 with 150,000 iterations derives the key, matching the
 * desktop/web version of this tool so files are interchangeable.
 */
object CryptoUtil {
    private const val ITERATIONS = 150_000
    private const val KEY_LEN_BITS = 256

    /**
     * Renders the extracted salt+IV+ciphertext as a hashcat/John-style hash
     * string: $stego1$pbkdf2-sha256$<iterations>$<salt>$<iv>$<ciphertext+tag>.
     * This is the thing a password is actually being checked against — there
     * is no step where it gets "turned back into" the password; a candidate
     * is either checked and accepted, or checked and rejected.
     */
    fun formatHashString(blob: ByteArray): String {
        if (blob.size < 29) return "(invalid — too short to be a valid hash)"
        val salt = blob.copyOfRange(0, 16)
        val iv = blob.copyOfRange(16, 28)
        val ct = blob.copyOfRange(28, blob.size)
        return "\$stego1\$pbkdf2-sha256\$$ITERATIONS\$${hex(salt)}\$${hex(iv)}\$${hex(ct)}"
    }

    private fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02x".format(it) }

    fun seal(plaintext: ByteArray, password: String): ByteArray {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val key = deriveKey(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val ct = cipher.doFinal(plaintext)
        return salt + iv + ct
    }

    /** Throws (typically javax.crypto.AEADBadTagException) when the password is wrong. */
    fun unseal(blob: ByteArray, password: String): ByteArray {
        if (blob.size < 29) throw IllegalArgumentException("Corrupt data")
        val salt = blob.copyOfRange(0, 16)
        val iv = blob.copyOfRange(16, 28)
        val ct = blob.copyOfRange(28, blob.size)
        val key = deriveKey(password, salt)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return cipher.doFinal(ct)
    }

    private fun deriveKey(password: String, salt: ByteArray): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LEN_BITS)
        val bytes = factory.generateSecret(spec).encoded
        return SecretKeySpec(bytes, "AES")
    }

    // --- Fast path for password-recovery hot loops ---------------------------
    // getInstance() on SecretKeyFactory/Cipher does a JCE provider lookup each
    // call, which is wasted work when it's repeated for every single guess in
    // a tight multi-threaded loop. These thread-local instances are created
    // once per worker thread and reused for every guess that thread makes.

    private val threadFactory = ThreadLocal.withInitial { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256") }
    private val threadCipher = ThreadLocal.withInitial { Cipher.getInstance("AES/GCM/NoPadding") }

    /** Same contract as [unseal], but reuses this thread's cached crypto objects. Use only from a single fixed thread per call site. */
    fun unsealFast(blob: ByteArray, password: String): ByteArray {
        if (blob.size < 29) throw IllegalArgumentException("Corrupt data")
        val salt = blob.copyOfRange(0, 16)
        val iv = blob.copyOfRange(16, 28)
        val ct = blob.copyOfRange(28, blob.size)

        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LEN_BITS)
        val keyBytes = threadFactory.get()!!.generateSecret(spec).encoded
        val key = SecretKeySpec(keyBytes, "AES")

        val cipher = threadCipher.get()!!
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
        return cipher.doFinal(ct)
    }
}
