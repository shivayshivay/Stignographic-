package com.forensics.stego

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.forensics.stego.ui.AboutScreen
import com.forensics.stego.ui.CrackScreen
import com.forensics.stego.ui.DashboardScreen
import com.forensics.stego.ui.DecodeScreen
import com.forensics.stego.ui.EncodeScreen
import com.forensics.stego.ui.theme.StegoTheme
import kotlinx.coroutines.launch

sealed class Dest(val route: String, val label: String) {
    data object Dashboard : Dest("dashboard", "Dashboard")
    data object Encode : Dest("encode", "Encode")
    data object Decode : Dest("decode", "Decode")
    data object Crack : Dest("crack", "Password recovery")
    data object About : Dest("about", "Safety & about")
}

val drawerDestinations = listOf(Dest.Dashboard, Dest.Encode, Dest.Decode, Dest.Crack, Dest.About)

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            StegoTheme { AppRoot(vm) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: AppViewModel) {
    val nav = rememberNavController()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route ?: Dest.Dashboard.route

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    "Stego Forensics",
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 20.dp),
                    style = MaterialTheme.typography.titleLarge
                )
                HorizontalDivider()
                Spacer(Modifier.height(8.dp))
                drawerDestinations.forEach { dest ->
                    NavigationDrawerItem(
                        label = { Text(dest.label) },
                        selected = current == dest.route,
                        onClick = {
                            scope.launch { drawerState.close() }
                            nav.navigate(dest.route) {
                                popUpTo(Dest.Dashboard.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(drawerDestinations.firstOrNull { it.route == current }?.label ?: "Stego Forensics") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Open menu")
                        }
                    }
                )
            }
        ) { padding ->
            NavHost(
                navController = nav,
                startDestination = Dest.Dashboard.route,
                modifier = Modifier.padding(padding)
            ) {
                composable(Dest.Dashboard.route) { DashboardScreen { route -> nav.navigate(route) } }
                composable(Dest.Encode.route) { EncodeScreen(vm) }
                composable(Dest.Decode.route) { DecodeScreen(vm) { route -> nav.navigate(route) } }
                composable(Dest.Crack.route) { CrackScreen(vm) }
                composable(Dest.About.route) { AboutScreen() }
            }
        }
    }
}
