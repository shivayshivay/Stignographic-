package com.forensics.stego.core

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import android.os.Environment

/**
 * Loads an image defensively before it ever reaches the steganography engine:
 *  1. Size guard — refuses files above 10 MB or below a sane minimum, before
 *     any decode happens, so an oversized file can't exhaust memory.
 *  2. Format sniff — checks the real header bytes (not the file name or the
 *     MIME type the sender claims) against PNG/JPEG/BMP/GIF/WebP signatures.
 *     Anything else (including HTML, SVG or script content renamed to
 *     "photo.png") is rejected before Android ever touches it.
 *  3. Bounds-only decode — reads width/height without allocating pixel
 *     memory, and rejects images with an unreasonable pixel count.
 *  4. Full decode goes through Android's BitmapFactory, which only ever
 *     produces pixel data. Nothing in the file is parsed as code or markup,
 *     and nothing is ever executed, regardless of what bytes it contains.
 */
object SafeImageLoader {
    private const val MAX_BYTES = 10L * 1024 * 1024
    private const val MAX_PIXELS = 40_000_000L

    class UnsafeImageException(message: String) : Exception(message)

    fun load(context: Context, uri: Uri): Bitmap {
        val resolver = context.contentResolver

        val len = resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        if (len in 0 until 32) throw UnsafeImageException("File is too small to be a real image.")
        if (len > MAX_BYTES) throw UnsafeImageException("File is larger than 10 MB. Choose a smaller image.")

        val header = ByteArray(16)
        resolver.openInputStream(uri)?.use { it.read(header) }
            ?: throw UnsafeImageException("Could not read the file.")
        if (sniff(header) == null) {
            throw UnsafeImageException("Refused: this is not a genuine PNG, JPG, BMP, GIF or WebP image, even if the name says so.")
        }

        val boundsOpts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, boundsOpts) }
        val w = boundsOpts.outWidth
        val h = boundsOpts.outHeight
        if (w <= 0 || h <= 0) throw UnsafeImageException("The system could not decode this file. It may be corrupted or tampered with.")
        if (w.toLong() * h.toLong() > MAX_PIXELS) throw UnsafeImageException("Image dimensions are too large.")

        val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
        return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw UnsafeImageException("Could not decode the image.")
    }

    private fun sniff(b: ByteArray): String? {
        if (b.size < 12) return null
        if (b[0] == 0x89.toByte() && b[1] == 0x50.toByte() && b[2] == 0x4E.toByte() && b[3] == 0x47.toByte()) return "png"
        if (b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte() && b[2] == 0xFF.toByte()) return "jpeg"
        if (b[0] == 0x42.toByte() && b[1] == 0x4D.toByte()) return "bmp"
        if (b[0] == 'G'.code.toByte() && b[1] == 'I'.code.toByte() && b[2] == 'F'.code.toByte()) return "gif"
        if (b[0] == 'R'.code.toByte() && b[1] == 'I'.code.toByte() && b[8] == 'W'.code.toByte() && b[9] == 'E'.code.toByte()) return "webp"
        return null
    }
}

fun saveBitmapAsPng(context: Context, bitmap: Bitmap, filename: String): Uri? {
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, filename)
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/StegoForensics")
    }
    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
    val ok = resolver.openOutputStream(uri)?.use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out) }
    return if (ok == true) uri else null
}
