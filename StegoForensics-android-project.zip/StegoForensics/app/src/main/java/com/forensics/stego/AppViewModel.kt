package com.forensics.stego

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class AppViewModel : ViewModel() {
    var encodeSourceBitmap by mutableStateOf<Bitmap?>(null)
    var encodeResultBitmap by mutableStateOf<Bitmap?>(null)
    var decodeBitmap by mutableStateOf<Bitmap?>(null)
}
