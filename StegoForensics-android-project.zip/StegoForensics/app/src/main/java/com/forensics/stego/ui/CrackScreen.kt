package com.forensics.stego.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.forensics.stego.AppViewModel
import com.forensics.stego.core.PasswordCracker
import com.forensics.stego.core.SafeImageLoader
import com.forensics.stego.core.StegoEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

@Composable
fun CrackScreen(vm: AppViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val cores = remember { Runtime.getRuntime().availableProcessors().coerceIn(1, 16) }

    var status by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    var payload by remember { mutableStateOf<ByteArray?>(null) }
    var wordlist by remember { mutableStateOf<List<String>>(emptyList()) }

    // Rule attack toggles
    var ruleLeet by remember { mutableStateOf(false) }
    var ruleCapitalize by remember { mutableStateOf(false) }
    var ruleUpper by remember { mutableStateOf(false) }
    var rulePrependSymbol by remember { mutableStateOf(false) }
    var ruleWrapSymbol by remember { mutableStateOf(false) }
    var ruleDigits by remember { mutableStateOf(false) }
    var ruleSuffixes by remember { mutableStateOf(false) }
    var ruleYears by remember { mutableStateOf(false) }
    var ruleReverse by remember { mutableStateOf(false) }

    // Mask attack
    var useMask by remember { mutableStateOf(false) }
    var mask by remember { mutableStateOf("") }

    // Brute force
    var useBrute by remember { mutableStateOf(false) }
    var maxLen by remember { mutableIntStateOf(4) }

    var progress by remember { mutableStateOf<PasswordCracker.Progress?>(null) }
    var result by remember { mutableStateOf<PasswordCracker.Result?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        status = null; result = null; payload = null; progress = null
        try {
            val bmp = SafeImageLoader.load(context, uri)
            val (encrypted, data) = StegoEngine.extract(bmp)
            if (!encrypted) {
                status = "This image's hidden message is not password-protected. Use Decode instead."
                isError = true
            } else {
                payload = data
                status = "Encrypted hidden message found. Ready to search for the password."
                isError = false
            }
        } catch (e: StegoEngine.StegoException) {
            status = "No hidden message from this app was found in this image."; isError = true
        } catch (e: Exception) {
            status = e.message; isError = true
        }
    }

    val wordlistPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            val lines = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readLines() ?: emptyList()
            wordlist = lines.map { it.trim() }.filter { it.isNotEmpty() }.take(500_000)
            status = "Loaded ${wordlist.size} candidate passwords from word list."
            isError = false
        } catch (e: Exception) {
            status = "Could not read the word list file."; isError = true
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            "Runs on all $cores CPU cores on this device. Only a password that is actually tried can be found — " +
                "a long, random, unique password will not be recovered in practical time, by this or any tool.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Button(onClick = { imagePicker.launch("image/*") }) { Text("Choose image with encrypted message") }
        Button(onClick = { wordlistPicker.launch("text/plain") }) { Text("Load word list (.txt, optional)") }
        if (wordlist.isNotEmpty()) Text("${wordlist.size} words loaded.", style = MaterialTheme.typography.bodySmall)

        HorizontalDivider()
        Text("Rule attack — try common variations of each word", style = MaterialTheme.typography.titleSmall)
        Text(
            "E.g. with a wordlist containing \"claude\", enabling Capitalize + Wrap with a symbol + Append common suffixes will also try \"@Claude@123\".",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        RuleToggle("Leetspeak (a→4, e→3, i→1, o→0, s→5)", ruleLeet) { ruleLeet = it }
        RuleToggle("Capitalize first letter", ruleCapitalize) { ruleCapitalize = it }
        RuleToggle("ALL UPPERCASE", ruleUpper) { ruleUpper = it }
        RuleToggle("Prepend a symbol (@word, !word, #word…)", rulePrependSymbol) { rulePrependSymbol = it }
        RuleToggle("Wrap with a symbol (@word@, !word!…)", ruleWrapSymbol) { ruleWrapSymbol = it }
        RuleToggle("Append a single digit (0–9)", ruleDigits) { ruleDigits = it }
        RuleToggle("Append common suffixes (123, !, 007, …)", ruleSuffixes) { ruleSuffixes = it }
        RuleToggle("Append a year (1970–2030)", ruleYears) { ruleYears = it }
        RuleToggle("Reversed word", ruleReverse) { ruleReverse = it }

        HorizontalDivider()
        Text("Mask attack — search a known pattern", style = MaterialTheme.typography.titleSmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = useMask, onCheckedChange = { useMask = it })
            Text("Use a mask")
        }
        if (useMask) {
            OutlinedTextField(
                value = mask, onValueChange = { mask = it },
                label = { Text("Mask, e.g. Delhi?d?d?d?d") },
                supportingText = { Text("?l lowercase  ?u uppercase  ?d digit  ?s symbol  ?a any — everything else is literal") },
                modifier = Modifier.fillMaxWidth()
            )
        }

        HorizontalDivider()
        Text("Brute force — exhaustive search, slowest option", style = MaterialTheme.typography.titleSmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = useBrute, onCheckedChange = { useBrute = it })
            Text("Also brute-force lowercase letters + digits, up to length $maxLen")
        }
        if (useBrute) {
            Slider(value = maxLen.toFloat(), onValueChange = { maxLen = it.toInt() }, valueRange = 1f..6f, steps = 4)
            Text(
                "Length 6 over this character set is about 2.2 billion combinations. Spread across $cores cores this is still slow on a phone — use a mask or wordlist first when possible.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        status?.let { Text(it, color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                enabled = payload != null && job == null,
                onClick = {
                    val data = payload ?: return@Button
                    result = null
                    val rules = PasswordCracker.RuleOptions(
                        leetSpeak = ruleLeet,
                        capitalizeFirst = ruleCapitalize,
                        upperCase = ruleUpper,
                        prependSymbol = rulePrependSymbol,
                        wrapSymbol = ruleWrapSymbol,
                        appendDigits0to9 = ruleDigits,
                        appendCommonSuffixes = ruleSuffixes,
                        appendYears = ruleYears,
                        reverseWord = ruleReverse
                    )
                    val maskConfig = if (useMask && mask.isNotBlank()) PasswordCracker.MaskConfig(mask) else null
                    val brute = if (useBrute) PasswordCracker.BruteForceConfig("abcdefghijklmnopqrstuvwxyz0123456789", 1, maxLen) else null
                    job = scope.launch {
                        val r = PasswordCracker.attack(data, wordlist, rules, maskConfig, brute) { p -> progress = p }
                        result = r
                        job = null
                    }
                }
            ) { Text("Start search") }

            if (job != null) {
                OutlinedButton(onClick = { job?.cancel(); job = null }) { Text("Stop") }
            }
        }

        progress?.let { p ->
            if (job != null) {
                LinearProgressIndicator(
                    progress = { if (p.total > 0) (p.tried.toFloat() / p.total.toFloat()).coerceIn(0f, 1f) else 0f },
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "${p.phase} — tried ${p.tried} of ~${p.total} — currently trying: ${p.currentGuess}",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        result?.let { r ->
            if (r.found) {
                Text("Password found: ${r.password}", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text("Hidden message", style = MaterialTheme.typography.titleSmall)
                SelectionContainer { Text(String(r.plaintext ?: ByteArray(0), Charsets.UTF_8)) }
            } else {
                Text(
                    "No password found among ${r.attempts} attempts. Try a wordlist, a mask, or a longer brute-force range.",
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}

@Composable
private fun RuleToggle(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = onChange)
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}
