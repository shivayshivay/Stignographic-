package com.forensics.stego.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.forensics.stego.AppViewModel
import com.forensics.stego.core.CryptoUtil
import com.forensics.stego.core.SafeImageLoader
import com.forensics.stego.core.StegoEngine
import com.forensics.stego.core.saveBitmapAsPng

@Composable
fun EncodeScreen(vm: AppViewModel) {
    val context = LocalContext.current
    var message by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    var capacity by remember { mutableStateOf<Int?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        status = null; vm.encodeResultBitmap = null
        try {
            val bmp = SafeImageLoader.load(context, uri)
            vm.encodeSourceBitmap = bmp
            capacity = StegoEngine.capacityBytes(bmp)
        } catch (e: Exception) {
            vm.encodeSourceBitmap = null; capacity = null
            status = e.message; isError = true
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("1. Choose a cover image", style = MaterialTheme.typography.titleSmall)
        Button(onClick = { picker.launch("image/*") }) { Text("Choose image") }

        vm.encodeSourceBitmap?.let { bmp ->
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp),
                contentScale = ContentScale.Fit
            )
            capacity?.let { Text("Verified image. Holds about $it bytes of text.", style = MaterialTheme.typography.bodySmall) }
        }

        Text("2. Write the message", style = MaterialTheme.typography.titleSmall)
        OutlinedTextField(
            value = message, onValueChange = { message = it },
            label = { Text("Secret message") }, modifier = Modifier.fillMaxWidth(), minLines = 4
        )
        OutlinedTextField(
            value = password, onValueChange = { password = it },
            label = { Text("Password (optional)") }, modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(autoCorrectEnabled = false)
        )

        Button(
            enabled = vm.encodeSourceBitmap != null && message.isNotEmpty(),
            onClick = {
                val source = vm.encodeSourceBitmap ?: return@Button
                try {
                    val plain = message.toByteArray(Charsets.UTF_8)
                    val payload = if (password.isNotEmpty()) CryptoUtil.seal(plain, password) else plain
                    vm.encodeResultBitmap = StegoEngine.embed(source, payload, password.isNotEmpty())
                    status = "Message hidden" + if (password.isNotEmpty()) " and encrypted." else "."
                    isError = false
                } catch (e: Exception) {
                    status = e.message; isError = true
                }
            }
        ) { Text("Hide message") }

        status?.let { Text(it, color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) }

        vm.encodeResultBitmap?.let { result ->
            Text("3. Save the result", style = MaterialTheme.typography.titleSmall)
            Image(
                bitmap = result.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp),
                contentScale = ContentScale.Fit
            )
            Button(onClick = {
                val uri = saveBitmapAsPng(context, result, "stego_${System.currentTimeMillis()}.png")
                status = if (uri != null) "Saved to Pictures/StegoForensics." else "Could not save the image."
                isError = uri == null
            }) { Text("Save to gallery") }
            Text(
                "Keep it as PNG. Sharing through apps that recompress photos (most chat apps) destroys the hidden message.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
