package com.forensics.stego.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AboutScreen() {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("How this app protects your device", style = MaterialTheme.typography.titleMedium)
        listOf(
            "Images are checked by their real header bytes, not the file name. Anything that isn't a genuine PNG, JPG, BMP, GIF or WebP is refused, even if it's named like one.",
            "Oversized files and images with an unreasonable pixel count are rejected before full decoding, which guards against memory-exhaustion attacks.",
            "Images are only ever decoded into plain pixel data by Android's standard image decoder, then re-drawn on screen. Nothing inside an image file is parsed as code or markup, and nothing in it is ever executed.",
            "Decoded text is shown as plain, non-interactive text, so it can never run as code or open a link on its own.",
            "This app makes no network requests. Images, word lists and results stay on the device."
        ).forEach { Text("•  $it", style = MaterialTheme.typography.bodyMedium) }

        Spacer(Modifier.height(6.dp))
        Text("Lawful use", style = MaterialTheme.typography.titleMedium)
        Text(
            "The password recovery feature is a dictionary and brute-force search, the same technique used by standard " +
                "forensic tools. Use it only on material you are legally authorised to examine, as part of a documented " +
                "investigation and proper chain of custody.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
