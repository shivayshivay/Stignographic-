package com.forensics.stego.core

import android.graphics.Bitmap

/**
 * Hides and recovers data inside the least-significant bit of each pixel's
 * red, green and blue channel. Alpha is left untouched. A 9-byte header
 * ("STG1" + encrypted flag + 4-byte big-endian length) precedes the payload
 * so extraction can tell a real hit from random noise.
 */
object StegoEngine {

    private val MAGIC = byteArrayOf(0x53, 0x54, 0x47, 0x31) // "STG1"
    private const val HEADER_SIZE = 9

    class StegoException(message: String) : Exception(message)

    fun capacityBytes(bitmap: Bitmap): Int {
        val bits = bitmap.width.toLong() * bitmap.height.toLong() * 3L
        return (((bits / 8) - HEADER_SIZE).coerceAtLeast(0)).toInt()
    }

    fun embed(bitmap: Bitmap, payload: ByteArray, encrypted: Boolean): Bitmap {
        val header = ByteArray(HEADER_SIZE)
        MAGIC.copyInto(header, 0)
        header[4] = if (encrypted) 1 else 0
        writeIntBE(header, 5, payload.size)
        val all = header + payload

        val cap = capacityBytes(bitmap)
        if (payload.size > cap) {
            throw StegoException("Message is too big for this image. It holds about $cap bytes of text.")
        }

        val out = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val w = out.width
        val h = out.height
        val pixels = IntArray(w * h)
        out.getPixels(pixels, 0, w, 0, 0, w, h)

        var bit = 0
        val totalBits = all.size * 8
        var i = 0
        while (i < pixels.size && bit < totalBits) {
            val p = pixels[i]
            val a = (p ushr 24) and 0xFF
            var r = (p ushr 16) and 0xFF
            var g = (p ushr 8) and 0xFF
            var b = p and 0xFF

            if (bit < totalBits) { r = setLsb(r, nextBit(all, bit)); bit++ }
            if (bit < totalBits) { g = setLsb(g, nextBit(all, bit)); bit++ }
            if (bit < totalBits) { b = setLsb(b, nextBit(all, bit)); bit++ }

            pixels[i] = (a shl 24) or (r shl 16) or (g shl 8) or b
            i++
        }
        out.setPixels(pixels, 0, w, 0, 0, w, h)
        return out
    }

    /** Returns (wasEncrypted, rawPayloadBytes). Throws StegoException if no valid header is found. */
    fun extract(bitmap: Bitmap): Pair<Boolean, ByteArray> {
        val w = bitmap.width
        val h = bitmap.height
        val pixels = IntArray(w * h)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        var pos = 0
        fun take(n: Int): ByteArray {
            val out = ByteArray(n)
            var bit = 0
            val total = n * 8
            while (bit < total) {
                val pixelIndex = pos / 3
                if (pixelIndex >= pixels.size) throw StegoException("none")
                val channel = pos % 3
                val p = pixels[pixelIndex]
                val value = when (channel) {
                    0 -> (p ushr 16) and 0xFF
                    1 -> (p ushr 8) and 0xFF
                    else -> p and 0xFF
                }
                val bitVal = value and 1
                out[bit / 8] = (out[bit / 8].toInt() or (bitVal shl (7 - (bit % 8)))).toByte()
                bit++
                pos++
            }
            return out
        }

        val header = take(HEADER_SIZE)
        for (idx in 0..3) if (header[idx] != MAGIC[idx]) throw StegoException("none")
        val encrypted = header[4].toInt() == 1
        val len = readIntBE(header, 5)
        val cap = capacityBytes(bitmap)
        if (len < 0 || len > cap) throw StegoException("none")
        return encrypted to take(len)
    }

    private fun setLsb(value: Int, bit: Int): Int = (value and 0xFE) or bit

    private fun nextBit(data: ByteArray, bit: Int): Int =
        (data[bit / 8].toInt() ushr (7 - (bit % 8))) and 1

    private fun writeIntBE(buf: ByteArray, offset: Int, value: Int) {
        buf[offset] = ((value ushr 24) and 0xFF).toByte()
        buf[offset + 1] = ((value ushr 16) and 0xFF).toByte()
        buf[offset + 2] = ((value ushr 8) and 0xFF).toByte()
        buf[offset + 3] = (value and 0xFF).toByte()
    }

    private fun readIntBE(buf: ByteArray, offset: Int): Int =
        ((buf[offset].toInt() and 0xFF) shl 24) or
            ((buf[offset + 1].toInt() and 0xFF) shl 16) or
            ((buf[offset + 2].toInt() and 0xFF) shl 8) or
            (buf[offset + 3].toInt() and 0xFF)
}
