package com.forensics.stego.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.coroutineContext

/**
 * Attempts to recover the password protecting a hidden message, using the
 * same techniques standard forensic password-recovery tools use:
 *
 *  1. Dictionary attack — a built-in common-password list plus an optional
 *     wordlist you load.
 *  2. Rule attack       — case, leetspeak and suffix mutations applied to
 *     every dictionary word (the same idea as hashcat/John the Ripper rule
 *     files), to catch "Password123!" from a wordlist that only has
 *     "password".
 *  3. Mask attack        — a known pattern (e.g. "Delhi##" for a word
 *     followed by two digits), searched exhaustively. Far faster than a
 *     blind brute force when part of the password's shape is known.
 *  4. Brute force         — exhaustive search over a character set and
 *     length range, used last because it's the slowest per password found.
 *
 * All four phases split their work across every available CPU core. This
 * can only find a password that is actually tried: a long, random, unique
 * password will not be recovered in practical time by this or any tool —
 * that's a property of AES-256 + PBKDF2, not a limitation of this app.
 */
object PasswordCracker {

    data class Progress(val tried: Long, val total: Long, val currentGuess: String, val phase: String)
    data class Result(val found: Boolean, val password: String?, val plaintext: ByteArray?, val attempts: Long)

    data class RuleOptions(
        val leetSpeak: Boolean = false,
        val capitalizeFirst: Boolean = false,
        val upperCase: Boolean = false,
        val appendDigits0to9: Boolean = false,
        val appendCommonSuffixes: Boolean = false,
        val appendYears: Boolean = false,
        val reverseWord: Boolean = false
    ) {
        fun isAnyEnabled(): Boolean =
            leetSpeak || capitalizeFirst || upperCase || appendDigits0to9 ||
                appendCommonSuffixes || appendYears || reverseWord
    }

    private val COMMON_SUFFIXES = listOf("123", "1234", "12345", "!", "@", "#", "01", "007", "999", "000")
    private val YEARS = (1970..2030).map { it.toString() }

    /** Expands one word into itself plus every mutation enabled in [rules]. */
    fun mutate(word: String, rules: RuleOptions): List<String> {
        if (!rules.isAnyEnabled()) return listOf(word)
        val out = LinkedHashSet<String>()
        out.add(word)

        if (rules.capitalizeFirst && word.isNotEmpty()) {
            out.add(word.replaceFirstChar { it.uppercase() })
        }
        if (rules.upperCase) out.add(word.uppercase())
        if (rules.reverseWord) out.add(word.reversed())

        if (rules.leetSpeak) {
            val leet = word
                .replace('a', '4').replace('A', '4')
                .replace('e', '3').replace('E', '3')
                .replace('i', '1').replace('I', '1')
                .replace('o', '0').replace('O', '0')
                .replace('s', '5').replace('S', '5')
            out.add(leet)
        }

        val bases = out.toList() // snapshot before suffix expansion, to avoid compounding growth
        if (rules.appendDigits0to9) {
            for (b in bases) for (d in 0..9) out.add(b + d)
        }
        if (rules.appendCommonSuffixes) {
            for (b in bases) for (s in COMMON_SUFFIXES) out.add(b + s)
        }
        if (rules.appendYears) {
            for (b in bases) for (y in YEARS) out.add(b + y)
        }

        return out.toList()
    }

    val COMMON_PASSWORDS = listOf(
        "123456", "password", "12345678", "qwerty", "123456789", "12345", "1234",
        "111111", "1234567", "dragon", "123123", "baseball", "iloveyou", "admin",
        "welcome", "monkey", "login", "abc123", "letmein", "000000", "password1",
        "qwerty123", "1q2w3e4r", "princess", "football", "696969", "asdfgh",
        "shadow", "master", "superman", "trustno1", "sunshine", "hello", "freedom",
        "passw0rd", "starwars", "whatever", "charlie", "aa123456", "donald", "changeme"
    )

    /** A hashcat-style mask: ?l lowercase, ?u uppercase, ?d digit, ?s symbol, ?a any; any other character is literal. */
    class MaskConfig(mask: String) {
        private val lower = ('a'..'z').toList()
        private val upper = ('A'..'Z').toList()
        private val digit = ('0'..'9').toList()
        private val symbol = "!@#\$%^&*()-_=+".toList()
        private val positions: List<List<Char>>

        init {
            val result = mutableListOf<List<Char>>()
            var i = 0
            while (i < mask.length) {
                if (mask[i] == '?' && i + 1 < mask.length) {
                    when (mask[i + 1]) {
                        'l' -> result.add(lower)
                        'u' -> result.add(upper)
                        'd' -> result.add(digit)
                        's' -> result.add(symbol)
                        'a' -> result.add(lower + upper + digit + symbol)
                        else -> result.add(listOf(mask[i + 1]))
                    }
                    i += 2
                } else {
                    result.add(listOf(mask[i]))
                    i += 1
                }
            }
            positions = result
        }

        fun total(): Long = positions.fold(1L) { acc, p -> acc * p.size }

        fun combinationAt(index: Long): String {
            var rem = index
            val chars = CharArray(positions.size)
            for (p in positions.indices.reversed()) {
                val base = positions[p].size
                chars[p] = positions[p][(rem % base).toInt()]
                rem /= base
            }
            return String(chars)
        }
    }

    class BruteForceConfig(val charset: String, val minLen: Int, val maxLen: Int) {
        fun rangeTotal(len: Int): Long = Math.pow(charset.length.toDouble(), len.toDouble()).toLong()
        fun totalCombinations(): Long = (minLen..maxLen).sumOf { rangeTotal(it) }

        fun combinationAt(len: Int, index: Long): String {
            var rem = index
            val chars = CharArray(len)
            for (p in len - 1 downTo 0) {
                chars[p] = charset[(rem % charset.length).toInt()]
                rem /= charset.length
            }
            return String(chars)
        }
    }

    suspend fun attack(
        blob: ByteArray,
        wordlist: List<String>,
        rules: RuleOptions,
        maskConfig: MaskConfig?,
        bruteForce: BruteForceConfig?,
        onProgress: (Progress) -> Unit
    ): Result = coroutineScope {
        val workerCount = Runtime.getRuntime().availableProcessors().coerceIn(1, 16)

        // Build the dictionary + rule-mutation candidate list and work out every
        // phase's size up front, so progress has a real total from the start.
        val baseWords = (COMMON_PASSWORDS + wordlist).distinct()
        val expanded = ArrayList<String>(baseWords.size * 4)
        for (w in baseWords) {
            expanded.addAll(mutate(w, rules))
            if (expanded.size > 3_000_000) break // hard safety cap
        }
        val maskTotal = maskConfig?.total() ?: 0L
        val bruteTotal = bruteForce?.totalCombinations() ?: 0L
        val grandTotal = expanded.size.toLong() + maskTotal + bruteTotal

        val attempts = AtomicLong(0)
        val found = AtomicReference<Result?>(null)
        val stop = AtomicBoolean(false)
        val currentGuess = AtomicReference("")
        var currentPhase = "Dictionary + rules"

        // Background ticker: reports progress at a steady rate regardless of
        // how many worker threads are hammering the counter.
        val ticker = launch(Dispatchers.Default) {
            while (isActive && !stop.get()) {
                onProgress(Progress(attempts.get(), grandTotal, currentGuess.get(), currentPhase))
                delay(120)
            }
        }

        fun tryOne(candidate: String): ByteArray? = try {
            CryptoUtil.unseal(blob, candidate)
        } catch (e: Exception) {
            null
        }

        suspend fun runParallel(total: Long, phase: String, resolve: (Long) -> String) {
            if (stop.get() || total <= 0) return
            currentPhase = phase
            val chunk = (total / workerCount).coerceAtLeast(1)
            coroutineScope {
                (0 until workerCount).map { w ->
                    async(Dispatchers.Default) {
                        val start = w * chunk
                        val end = if (w == workerCount - 1) total else minOf(start + chunk, total)
                        var idx = start
                        while (idx < end && !stop.get()) {
                            coroutineContext.ensureActive()
                            val candidate = resolve(idx)
                            currentGuess.set(candidate)
                            attempts.incrementAndGet()
                            val plain = tryOne(candidate)
                            if (plain != null) {
                                found.compareAndSet(null, Result(true, candidate, plain, attempts.get()))
                                stop.set(true)
                                return@async
                            }
                            idx++
                        }
                    }
                }.awaitAll()
            }
        }

        try {
            // Phase 1: dictionary + rule mutations.
            runParallel(expanded.size.toLong(), "Dictionary + rules") { i -> expanded[i.toInt()] }

            // Phase 2: mask attack.
            if (found.get() == null && maskConfig != null) {
                runParallel(maskConfig.total(), "Mask attack") { i -> maskConfig.combinationAt(i) }
            }

            // Phase 3: brute force, length by length.
            if (found.get() == null && bruteForce != null) {
                for (len in bruteForce.minLen..bruteForce.maxLen) {
                    if (found.get() != null) break
                    runParallel(bruteForce.rangeTotal(len), "Brute force (length $len)") { i -> bruteForce.combinationAt(len, i) }
                }
            }
        } finally {
            stop.set(true)
            ticker.cancel()
        }

        found.get() ?: Result(false, null, null, attempts.get())
    }
}
