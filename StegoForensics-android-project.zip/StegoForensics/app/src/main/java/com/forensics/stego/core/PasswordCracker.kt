package com.forensics.stego.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlin.coroutines.coroutineContext

/**
 * Attempts to recover the password protecting a hidden message.
 *
 * This is a dictionary + brute-force attack, the same approach real forensic
 * password-recovery tools use. It can only find a password that is actually
 * tried. A long, random, unique password will not be recovered in practical
 * time by this or any other tool — that is a property of AES-256 and
 * PBKDF2, not a limitation of this app. Use it to recover weak or
 * human-chosen passwords, with a wordlist (e.g. a standard forensic
 * wordlist) for best results.
 */
object PasswordCracker {

    data class Progress(val tried: Long, val total: Long, val currentGuess: String)
    data class Result(val found: Boolean, val password: String?, val plaintext: ByteArray?, val attempts: Long)

    class BruteForceConfig(private val charset: String, private val minLen: Int, private val maxLen: Int) {
        fun totalCombinations(): Long {
            var sum = 0L
            for (len in minLen..maxLen) sum += Math.pow(charset.length.toDouble(), len.toDouble()).toLong()
            return sum
        }

        fun sequence(): Sequence<String> = sequence {
            for (len in minLen..maxLen) {
                val idx = IntArray(len)
                while (true) {
                    yield(String(CharArray(len) { charset[idx[it]] }))
                    var pos = len - 1
                    while (pos >= 0) {
                        idx[pos]++
                        if (idx[pos] < charset.length) break
                        idx[pos] = 0
                        pos--
                    }
                    if (pos < 0) break
                }
            }
        }
    }

    val COMMON_PASSWORDS = listOf(
        "123456", "password", "12345678", "qwerty", "123456789", "12345", "1234",
        "111111", "1234567", "dragon", "123123", "baseball", "iloveyou", "admin",
        "welcome", "monkey", "login", "abc123", "letmein", "000000", "password1",
        "qwerty123", "1q2w3e4r", "princess", "football", "696969", "asdfgh",
        "shadow", "master", "superman", "trustno1", "sunshine", "hello", "freedom",
        "passw0rd", "starwars", "whatever", "charlie", "aa123456", "donald", "changeme"
    )

    suspend fun attack(
        blob: ByteArray,
        wordlist: List<String>,
        bruteForce: BruteForceConfig?,
        onProgress: (Progress) -> Unit
    ): Result = withContext(Dispatchers.Default) {
        var attempts = 0L
        val candidates = (COMMON_PASSWORDS + wordlist).distinct()
        val bruteTotal = bruteForce?.totalCombinations() ?: 0L
        val total = candidates.size.toLong() + bruteTotal

        for (candidate in candidates) {
            coroutineContext.ensureActive()
            attempts++
            onProgress(Progress(attempts, total, candidate))
            tryOne(blob, candidate)?.let { return@withContext Result(true, candidate, it, attempts) }
        }

        if (bruteForce != null) {
            for (candidate in bruteForce.sequence()) {
                coroutineContext.ensureActive()
                attempts++
                if (attempts % 25L == 0L) onProgress(Progress(attempts, total, candidate))
                tryOne(blob, candidate)?.let { return@withContext Result(true, candidate, it, attempts) }
            }
        }

        Result(false, null, null, attempts)
    }

    private fun tryOne(blob: ByteArray, candidate: String): ByteArray? = try {
        CryptoUtil.unseal(blob, candidate)
    } catch (e: Exception) {
        null
    }
}
