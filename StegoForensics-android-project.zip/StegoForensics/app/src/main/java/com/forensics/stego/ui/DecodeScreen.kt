package com.forensics.stego.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.forensics.stego.AppViewModel
import com.forensics.stego.Dest
import com.forensics.stego.core.CryptoUtil
import com.forensics.stego.core.SafeImageLoader
import com.forensics.stego.core.StegoEngine

@Composable
fun DecodeScreen(vm: AppViewModel, onNavigate: (String) -> Unit) {
    val context = LocalContext.current
    var password by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    var isError by remember { mutableStateOf(false) }
    var revealed by remember { mutableStateOf<String?>(null) }
    var needsPassword by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        status = null; revealed = null; needsPassword = false
        try {
            val bmp = SafeImageLoader.load(context, uri)
            vm.decodeBitmap = bmp
            status = "Verified image, ${bmp.width} x ${bmp.height} px."
            isError = false
        } catch (e: Exception) {
            vm.decodeBitmap = null; status = e.message; isError = true
        }
    }

    fun attemptReveal() {
        val bmp = vm.decodeBitmap ?: return
        needsPassword = false
        try {
            val (encrypted, data) = StegoEngine.extract(bmp)
            if (encrypted) {
                if (password.isEmpty()) {
                    needsPassword = true
                    status = "This message is encrypted. Enter the password, or use Password recovery."
                    isError = true
                    return
                }
                val plain = CryptoUtil.unseal(data, password)
                revealed = String(plain, Charsets.UTF_8)
                status = "Message revealed."; isError = false
            } else {
                revealed = String(data, Charsets.UTF_8)
                status = "Message revealed."; isError = false
            }
        } catch (e: StegoEngine.StegoException) {
            status = "No hidden message from this app was found in this image."; isError = true
        } catch (e: Exception) {
            status = "Wrong password, or the data was altered."; isError = true
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Button(onClick = { picker.launch("image/*") }) { Text("Choose image") }

        vm.decodeBitmap?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxWidth().heightIn(max = 200.dp),
                contentScale = ContentScale.Fit
            )
        }

        OutlinedTextField(
            value = password, onValueChange = { password = it },
            label = { Text("Password (if known)") }, modifier = Modifier.fillMaxWidth(),
            visualTransformation = PasswordVisualTransformation()
        )

        Button(enabled = vm.decodeBitmap != null, onClick = { attemptReveal() }) { Text("Reveal message") }

        status?.let { Text(it, color = if (isError) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary) }

        if (needsPassword) {
            TextButton(onClick = { onNavigate(Dest.Crack.route) }) { Text("Try password recovery instead") }
        }

        revealed?.let {
            Text("Hidden message", style = MaterialTheme.typography.titleSmall)
            SelectionContainer { Text(it, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}
