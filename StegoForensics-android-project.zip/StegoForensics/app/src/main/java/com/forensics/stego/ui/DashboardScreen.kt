package com.forensics.stego.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.forensics.stego.Dest

@Composable
fun DashboardScreen(onNavigate: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Image steganography toolkit", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Hide messages inside images, reveal messages that are already hidden, and recover a password protecting one.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        DashboardTile("Encode", "Hide a message inside an image.") { onNavigate(Dest.Encode.route) }
        DashboardTile("Decode", "Reveal a message from an image.") { onNavigate(Dest.Decode.route) }
        DashboardTile("Password recovery", "Recover a password protecting a hidden message.") { onNavigate(Dest.Crack.route) }
        DashboardTile("Safety & about", "How this app protects your device.") { onNavigate(Dest.About.route) }
    }
}

@Composable
private fun DashboardTile(title: String, subtitle: String, onClick: () -> Unit) {
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(18.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
